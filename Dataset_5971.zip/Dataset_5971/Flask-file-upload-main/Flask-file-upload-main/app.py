
from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
from flask import Flask, render_template, request
import pickle
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences
from PIL import Image
from pytesseract import pytesseract
import os
from os import listdir


with open('E:/Dessertation/Dataset_5971/fruad_model/tokenizer.pkl', 'rb') as input:
    tokenizer = pickle.load(input)

def load_model():
    model = tf.keras.models.load_model("E:/Dessertation/Dataset_5971/fruad_model")
    return model


classifier = load_model()
cv = pickle.load(open('E:/Dessertation/Dataset_5971/fruad_model/tokenizer.pkl','rb'))

#app = Flask(__name__)
app=Flask(__name__,template_folder='E:/Dessertation/Dataset_5971/Flask-file-upload-main/Flask-file-upload-main/templates')

app.config["UPLOAD_FOLDER"] = "E:/Dessertation/Dataset_5971/Flask-file-upload-main/Flask-file-upload-main"

def Image_reading():
    path_to_tesseract = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
    pytesseract.tesseract_cmd = path_to_tesseract

    files = os.listdir(r'E:\Dessertation\Dataset_5971\Flask-file-upload-main')
    files = list(filter(lambda x: '.jpg' in x, files))
    sms_text= []

    i = 0
    while i in range(len(files)):
        img = Image.open(os.path.join(r'E:\Dessertation\Dataset_5971\Flask-file-upload-main', files[i]))
        #img = Image.open(os.path.join(app.config['UPLOAD_FOLDER'] + filename,"r", files[i]))
        text = pytesseract.image_to_string(img,lang="ENG")
        sms_text.append(text)
        i=i+1
    return sms_text 


@app.route('/')
def upload_file():
    return render_template('E:/Dessertation/Dataset_5971/Flask-file-upload-main/Flask-file-upload-main/templates/index.html')
    #return render_template('E:/Dessertation/Dataset_5971/template/index.html')


@app.route('/display', methods = ['GET', 'POST'])
def save_file():
    if request.method == 'POST':
        f = request.files['file']
        filename = secure_filename(f.filename)

        f.save(app.config['UPLOAD_FOLDER'] + filename)
        Image_reading()
        x=Image_reading()
        content=x
        max_length = 8
        sms_proc = tokenizer.texts_to_sequences(content)
        sms_proc = pad_sequences(sms_proc, maxlen=max_length, padding='post')
        my_prediction = (classifier.predict(sms_proc) > 0.5).astype("int32")
    #return render_template('E:/Dessertation/Dataset_5971/result.html', prediction=my_prediction)
        
    return render_template('E:/Dessertation/Dataset_5971/Flask-file-upload-main/Flask-file-upload-main/templates/content1.html', prediction=my_prediction) 
            


# @app.route('/predict',methods=['POST'])
# def predict():
#     if request.method == 'POST':
#         message = request.form['message']
#         sms = [message]
#         max_length = 8
#         sms_proc = tokenizer.texts_to_sequences(sms)
#         sms_proc = pad_sequences(sms_proc, maxlen=max_length, padding='post')
#         my_prediction = (classifier.predict(sms_proc) > 0.5).astype("int32")
#     return render_template('E:/Dessertation/Dataset_5971/result.html', prediction=my_prediction)

if __name__ == '__main__':
    app.run()

