# -*- coding: utf-8 -*-
"""
Created on Fri Nov 11 14:48:36 2022

@author: abc
"""

from PIL import Image
from pytesseract import pytesseract
import os
from os import listdir

import pandas as pd
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

import pickle
import tensorflow as tf
from tensorflow.keras.preprocessing.sequence import pad_sequences

def Image_reading():
    path_to_tesseract = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
    pytesseract.tesseract_cmd = path_to_tesseract

    files = os.listdir(r'E:\Dessertation\Dataset_5971\Flask-file-upload-main')
    files = list(filter(lambda x: '.jpg' in x, files))
    sms_text= []

    i = 0
    while i in range(len(files)):
        img = Image.open(os.path.join(r'E:\Dessertation\Dataset_5971\Flask-file-upload-main', files[i]))
        #img = Image.open(os.path.join(app.config['UPLOAD_FOLDER'] + filename,"r", files[i]))
        text = pytesseract.image_to_string(img,lang="ENG")
        sms_text.append(text)
        i=i+1
    return sms_text    



with open('E:/Dessertation/Dataset_5971/fruad_model/tokenizer.pkl', 'rb') as input:
    tokenizer = pickle.load(input)

def load_model():
    model = tf.keras.models.load_model("E:/Dessertation/Dataset_5971/fruad_model")
    return model

def preprocessing_cleantext(text):
    text = text.lower()
    text=text.replace("</p>","") # removing </p>
    text=text.replace("<p>"," ")  # removing <p>
    text = text.replace("http", " ")
    text = text.replace("www", " ")
    text = re.sub(r'([a-z])\1+', r'\1', text)
    text = re.sub('\s+', ' ', text)
    text = re.sub('\.+', '.', text)
    text = re.sub(r"(?:\@|'|https?\://)\s+","",text) #delete punctuation
    text = re.sub("[^a-zA-Z]", " ",text)
    text=re.sub(r'[^\w\s]','',text) # remove punctuation
    text=re.sub("\d+","",text) # remove number from text
    tokens_text = nltk.word_tokenize(text) # tokenizing the documents
    stopwords=nltk.corpus.stopwords.words('english') #stopword reduction
    tokens_text=[w for w in tokens_text if w.lower() not in stopwords]
    tokens_text=[w.lower() for w in tokens_text] #convert to lower case
    tokens_text=[w for w in tokens_text if len(w)>2] #considering tokens with length>2(meaningful words)
    p= PorterStemmer() # stemming tokenized documents using Porter Stemmer
    tokens_text = [p.stem(w) for w in tokens_text]
    return text


classifier = load_model()
cv = pickle.load(open('E:/Dessertation/Dataset_5971/fruad_model/tokenizer.pkl','rb'))

Image_reading()

x=Image_reading()
df = pd.DataFrame(x, columns=['message'])

#sms = ['Hi My name is Anjali Shinde. Studying MSC big data Analaytics.']
content=df["message"].apply(preprocessing_cleantext)

max_length = 8
sms_proc = tokenizer.texts_to_sequences(content)
sms_proc = pad_sequences(sms_proc, maxlen=max_length, padding='post')
my_prediction = (classifier.predict(sms_proc) > 0.5).astype("int32")
print(my_prediction)