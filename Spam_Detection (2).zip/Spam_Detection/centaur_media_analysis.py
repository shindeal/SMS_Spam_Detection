# -*- coding: utf-8 -*-
"""
Created on Thu Jun  1 15:05:25 2023

@author: abc
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import csv

web_reg_data = pd.read_csv("C:/Users/abc/Desktop/CentaurMedia/web_reg_data.csv")
off_lineactivity_data = pd.read_csv("C:/Users/abc/Desktop/CentaurMedia/offline_activity.csv")
subscription_data = pd.read_csv("C:/Users/abc/Desktop/CentaurMedia/subscription.csv")
online_engagement_data = pd.read_csv("C:/Users/abc/Desktop/CentaurMedia/online_engagement.csv")

#online_engagement_data_org = online_engagement_data_org.rename(columns={'End Date Date': 'End Date'})
online_engagement_data = online_engagement_data.rename(columns={'End Date Date': 'End Date'})

print(web_reg_data.isnull().sum())
print(off_lineactivity_data.isnull().sum())
print(subscription_data.isnull().sum())
print(online_engagement_data.isnull().sum())


#cleansing of website registration dataset
web_reg_data['Web Registration Date'] = web_reg_data['Web Registration Date'].replace('#VALUE!', pd.NaT)
web_reg_data['Last Website Activity Date'] = web_reg_data['Last Website Activity Date'].replace('#VALUE!', pd.NaT)
web_reg_data['Last Website Activity Type'] = web_reg_data['Last Website Activity Type'].str.strip().str.upper()
web_reg_data['Business Sector'] = web_reg_data['Business Sector'].str.strip().str.upper()
web_reg_data['Job Function'] = web_reg_data['Job Function'].str.strip().str.upper()

duplicate_rows = web_reg_data[web_reg_data.duplicated()]
print(duplicate_rows)


#cleansing of offline_activities dataset
off_lineactivity_data['Access Type'] = off_lineactivity_data['Access Type'].str.strip().str.upper()
off_lineactivity_data['Activity Name'] = off_lineactivity_data['Activity Name'].str.strip().str.upper()
off_lineactivity_data['Activity Instance'] = off_lineactivity_data['Activity Instance'].str.strip().str.upper()

duplicate_rows = off_lineactivity_data[off_lineactivity_data.duplicated(subset=None, keep='first')]
print(len(duplicate_rows))
print('Duplicate data: {}'.format(off_lineactivity_data.duplicated().sum()))
off_lineactivity_data.drop_duplicates(inplace = True)


#cleansing of subscription dataset
subscription_data['Status'] = subscription_data['Status'].str.strip().str.upper()
subscription_data['Product Type'] = subscription_data['Product Type'].str.strip().str.upper()
subscription_data['Product'] = subscription_data['Product'].str.strip().str.upper()

duplicate_rows_sub = subscription_data[subscription_data.duplicated(subset=None, keep='first')]
print(len(duplicate_rows_sub))
print('Duplicate data: {}'.format(subscription_data.duplicated().sum()))
subscription_data.drop_duplicates(inplace = True)

#cleansing of online_engagement_data dataset
duplicate_rows_online = online_engagement_data[online_engagement_data.duplicated(subset=None, keep='first')]
print(len(duplicate_rows_online))
print('Duplicate data: {}'.format(subscription_data.duplicated().sum()))
online_engagement_data.drop_duplicates(inplace = True)

print(web_reg_data.isnull().sum() * 100 / len(web_reg_data)) #to know % of missing values
print(off_lineactivity_data.isnull().sum() * 100 / len(off_lineactivity_data)) #to know % of missing values
print(subscription_data.isnull().sum() * 100 / len(subscription_data)) #to know % of missing values
print(online_engagement_data.isnull().sum() * 100 / len(online_engagement_data)) #to know % of missing values


#getting statitics of dataset
web_reg_data.describe()
off_lineactivity_data.describe()
subscription_data.describe()
online_engagement_data.describe()

def find_outliers_IQR(df):

   q1=df.quantile(0.25)

   q3=df.quantile(0.75)

   IQR=q3-q1

   outliers = df[((df<(q1-1.5*IQR)) | (df>(q3+1.5*IQR)))]

   return outliers


outliers_web = find_outliers_IQR(web_reg_data['User ID'])
outliers_off = find_outliers_IQR(off_lineactivity_data['User ID'])
outliers_sub = find_outliers_IQR(subscription_data['User ID'])
outliers_online = find_outliers_IQR(online_engagement_data['User ID'])
outliers_online = find_outliers_IQR(online_engagement_data['Page Views'])
outliers_online = find_outliers_IQR(online_engagement_data['Visits'])
print("number of outliers: "+ str(len(outliers_online)))
print("max outlier value: "+ str(outliers_online.max()))
print("min outlier value: "+ str(outliers_online.min()))
    
    
for column in online_engagement_data.columns:
    sns.boxplot(y=online_engagement_data[column])
    plt.title(f"Boxplot of {column}")
    plt.show()
    
    
# drop null values from Last Website Activity Date 10968
web_reg_data_org= web_reg_data.copy()
web_reg_data.dropna(inplace=True)
print(web_reg_data.isnull().sum() * 100 / len(web_reg_data)) #to know % of missing values


plt.figure()
plt.hist(online_engagement_data['Page Views'], bins=10)
plt.title('Histogram')
plt.xlabel('Page Views')
plt.ylabel('Frequency')
plt.show()

plt.figure()
plt.hist(online_engagement_data['Visits'], bins=10)
plt.title('Histogram')
plt.xlabel('Visits')
plt.ylabel('Frequency')
plt.show()

online_engagement_data['Page Views'].describe()
online_engagement_data['Visits'].describe()

online_engagement_data_org= online_engagement_data.copy()
print(online_engagement_data_org.isnull().sum() * 100 / len(online_engagement_data_org)) #to know % of missing values

web_reg_data.to_excel(r'C:\Users\abc\Desktop\CentaurMedia\EDA\web_reg_data.xlsx', index=False)
off_lineactivity_data.to_excel(r'C:\Users\abc\Desktop\CentaurMedia\EDA\off_lineactivity_data.xlsx', index=False)
subscription_data.to_excel(r'C:\Users\abc\Desktop\CentaurMedia\EDA\subscription_data.xlsx', index=False)
online_engagement_data_org.to_excel(r'C:\Users\abc\Desktop\CentaurMedia\EDA\online_engagement_data.xlsx', index=False)


##############################EDA####################3
