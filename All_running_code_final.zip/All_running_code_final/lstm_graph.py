# -*- coding: utf-8 -*-
"""
Created on Tue Dec 13 10:39:39 2022

@author: abc
"""



import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import warnings
warnings.filterwarnings("ignore")

import pickle
import tensorflow as tf
import wordcloud

from PIL import Image
from pytesseract import pytesseract
import os
from os import listdir
import pandas as pd
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer


# helps in text preprocessing
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer

    # helps in model building
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Dropout
from tensorflow.keras.layers import Embedding
from tensorflow.keras.callbacks import EarlyStopping

# split data into train and test set
from sklearn.model_selection import train_test_split

from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

df = pd.read_csv("E:/Dessertation/Dataset_5971/combine_spam_ham.csv",encoding= 'unicode_escape')

#df = pd.read_csv("E:\Dessertation\Python_code\Final_code\Dataset_5971 - Copy-1.csv",encoding= 'unicode_escape')

df.head()
data= df
data['LABEL'] = data['LABEL'].map( {'spam': 1, 'ham': 0} )
df.LABEL.value_counts()
df.shape

data_ham  = data[data['LABEL'] == 0].copy()
data_spam = data[data['LABEL'] == 1].copy()

def show_wordcloud(df, title):
    text = ' '.join(df['TEXT'].astype(str).tolist())
    stopwords = set(wordcloud.STOPWORDS)
    fig_wordcloud = wordcloud.WordCloud(stopwords=stopwords,background_color='lightgrey',
                    colormap='viridis', width=800, height=600).generate(text)
    plt.figure(figsize=(10,7), frameon=True)
    plt.imshow(fig_wordcloud)  
    plt.axis('off')
    plt.title(title, fontsize=20 )
    plt.show()

show_wordcloud(data_spam, "Spam messages")
show_wordcloud(data_ham, "Ham messages")


import collections
def word_count_plot(data):
     # finding words along with count
     word_counter = collections.Counter([word for sentence in data for word in sentence.split()])
     most_count = word_counter.most_common(30) # 30 most common words
     # sorted data frame
     most_count = pd.DataFrame(most_count, columns=["Word", "Count"]).sort_values(by="Count")
     most_count.plot.barh(x = "Word", y = "Count", color="green", figsize=(10, 15))
     
word_count_plot(df["TEXT"])



def preprocessing_cleantext(text):
    text = text.lower()
    text=text.replace("</p>","") # removing </p>
    text=text.replace("<p>"," ")  # removing <p>
    text = text.replace("http", " ")
    text = text.replace("www", " ")
    text = re.sub(r'([a-z])\1+', r'\1', text)
    text = re.sub('\s+', ' ', text)
    text = re.sub('\.+', '.', text)
    text = re.sub(r"(?:\@|'|https?\://)\s+","",text) #delete punctuation
    text = re.sub("[^a-zA-Z]", " ",text)
    text=re.sub(r'[^\w\s]','',text) # remove punctuation
    text=re.sub("\d+","",text) # remove number from text
    tokens_text = nltk.word_tokenize(text) # tokenizing the documents
    stopwords=nltk.corpus.stopwords.words('english') #stopword reduction
    tokens_text=[w for w in tokens_text if w.lower() not in stopwords]
    tokens_text=[w.lower() for w in tokens_text] #convert to lower case
    tokens_text=[w for w in tokens_text if len(w)>2] #considering tokens with length>2(meaningful words)
    p= PorterStemmer() # stemming tokenized documents using Porter Stemmer
    tokens_text = [p.stem(w) for w in tokens_text]
    return text


df["TEXT"] = df["TEXT"].apply(preprocessing_cleantext) #clean_text
df["TEXT"]

X = data['TEXT'].values
y = data['LABEL'].values
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)


# prepare tokenizer
t = Tokenizer()
X=t.fit_on_texts(X_train)   


# integer encode the documents
encoded_train = t.texts_to_sequences(X_train)
encoded_test = t.texts_to_sequences(X_test)
print(encoded_train[0:2])

max_length = 8
padded_train = pad_sequences(encoded_train, maxlen=max_length, padding='pre')
padded_test = pad_sequences(encoded_test, maxlen=max_length, padding='post')
print(padded_train)

vocab_size = len(t.word_index) + 1

def c_report(y_true, y_pred):
   print("Classification Report")
   print(classification_report(y_true, y_pred))
   acc_sc = accuracy_score(y_true, y_pred)
   print("Accuracy : "+ str(acc_sc))
   return acc_sc

def plot_confusion_matrix(y_true, y_pred):
   mtx = confusion_matrix(y_true, y_pred)
   sns.heatmap(mtx, annot=True, fmt='d', linewidths=.5, 
               cmap="Blues", cbar=False)
   plt.ylabel('True label')
   plt.xlabel('Predicted label')
   

early_stop = EarlyStopping(monitor='val_loss', mode='min', verbose=1, patience=10)


############################ Flatten model creation #############################
from keras.layers import Bidirectional,LSTM
from tensorflow.keras.callbacks import EarlyStopping
def create_flatten_model():
    model = Sequential()
    model.add(Embedding(vocab_size, 24, input_length=max_length))
    model.add(Flatten())
    model.add(Dense(500, activation='relu'))
    model.add(Dense(200, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(100, activation='relu'))
    model.add(Dense(1, activation='sigmoid'))
    return model

model= create_flatten_model()
# compile the model
model.compile(optimizer='rmsprop', loss='binary_crossentropy', metrics=['accuracy'])
# summarize the model
print(model.summary())

early_stop = EarlyStopping(monitor='val_loss', mode='min', verbose=1, patience=10)

# fit the model
flatten_model= model.fit(x=padded_train,
         y=y_train,
         epochs=50,
         validation_data=(padded_test, y_test), verbose=1,
         callbacks=[early_stop]
         )

   
preds = (model.predict(padded_test) > 0.5).astype("int32")
c_report(y_test, preds)
plot_confusion_matrix(y_test, preds)





#https://medium.com/mlearning-ai/the-classification-of-text-messages-using-lstm-bi-lstm-and-gru-f79b207f90ad

#https://myblindbird.com/spam-email-detection-using-machine-learning-projects-beginners-python/

#https://www.pluralsight.com/guides/data-visualization-deep-learning-model-using-matplotlib

#https://towardsdatascience.com/useful-plots-to-diagnose-your-neural-network-521907fa2f45